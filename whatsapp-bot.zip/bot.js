const { default: makeWASocket, useSingleFileAuthState, DisconnectReason } = require("@whiskeysockets/baileys");
const { Boom } = require("@hapi/boom");
const { state, saveState } = useSingleFileAuthState("./auth.json");

async function startBot() {
  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: true,
  });

  sock.ev.on("creds.update", saveState);

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === "close") {
      const shouldReconnect = (lastDisconnect?.error = new Boom(lastDisconnect?.error))?.output?.statusCode !== DisconnectReason.loggedOut;
      if (shouldReconnect) startBot();
    } else if (connection === "open") {
      console.log("✅ تم الاتصال بواتساب");
    }
  });

  // استقبال الأوامر
  sock.ev.on("messages.upsert", async (m) => {
    const msg = m.messages[0];
    if (!msg.message || msg.key.fromMe) return;

    const from = msg.key.remoteJid;
    const text = msg.message.conversation || msg.message.extendedTextMessage?.text;

    if (!text) return;

    const command = text.trim().toLowerCase();

    switch (command) {
      case "!مرحبا":
        await sock.sendMessage(from, { text: "أهلًا بك! 😊 كيف يمكنني مساعدتك؟" });
        break;

      case "!الوقت":
        const time = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
        await sock.sendMessage(from, { text: `🕒 الوقت الحالي هو: ${time}` });
        break;

      case "!تاريخ":
        const date = new Date().toLocaleDateString('ar-EG');
        await sock.sendMessage(from, { text: `📅 تاريخ اليوم: ${date}` });
        break;

      case "!مزحة":
        const jokes = [
          "😂 مرة واحد راح للدكتور قاله عندي ألم في كل جسمي، طلع بيكسر نفسه.",
          "🤣 مرة واحد ذهب للمكتبة قالها: عندكم كتب عن القلق؟ قالتله: في الدور اللي فوق… بس بلاش تطلع.",
          "😆 سألوا بخيل: إزاي بتخلي ابنك ينام بسرعة؟ قالهم: بحكي له قصة عن الفاتورة."
        ];
        await sock.sendMessage(from, { text: jokes[Math.floor(Math.random() * jokes.length)] });
        break;

      case "!قلب":
        await sock.sendMessage(from, { text: "❤️" });
        break;

      case "!رابط":
        await sock.sendMessage(from, { text: "🔗 رابط المجموعة: https://chat.whatsapp.com/xxxxxxxx" });
        break;

      case "!مساعدة":
        await sock.sendMessage(from, {
          text:
`📜 *قائمة الأوامر:*
!مرحبا – ترحيب
!الوقت – معرفة الوقت
!تاريخ – معرفة التاريخ
!مزحة – إرسال نكتة
!قلب – إرسال قلب
!رابط – رابط مجموعة
!مساعدة – عرض هذه القائمة`
        });
        break;
    }
  });
}

startBot();
