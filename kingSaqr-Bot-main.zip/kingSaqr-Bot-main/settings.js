const settings = {
  packname: 'King Saqr Bot',
  author: '‎',
  botName: "King Saqr Bot",
  botOwner: 'ابو ذياب', // Your name
  ownerNumber: '994405571044', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.0.8",
};

module.exports = settings;
