const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, message) {
    const helpMessage = `
╔═══════════════════╗
   *🤖 ${settings.botName || 'King Saqr-Bot-Bot'}🦾*  
   Version: *${settings.version || '2.0.2'}*
   by ${settings.botOwner || 'King Saqr'}
   YT : ${global.ytch}
╚═══════════════════╝

*Available Commands الأوامر المتاحة:*

╔═══════════════════╗
🌐 *General Commands الأوامر العامة*:🌐
║ ➤ .help or .menu
║ ➤ .ping
║ ➤ .alive
║ ➤ .tts <text>
║ ➤ .owner
║ ➤ .joke
║ ➤ .quote
║ ➤ .fact
║ ➤ .weather <city>
║ ➤ .news
║ ➤ .attp <text>
║ ➤ .lyrics <song_title>
║ ➤ .8ball <question>
║ ➤ .groupinfo
║ ➤ .staff or .admins 
║ ➤ .vv
║ ➤ .trt <text> <lang>
║ ➤ .ss <link>
║ ➤ .jid
╚═══════════════════╝ 

╔═══════════════════╗
💻 *Admin Commands أوامر المسؤول*:💻
║ ➤ .ban @user
║ ➤ .promote @user
║ ➤ .demote @user
║ ➤ .mute <minutes>
║ ➤ .unmute
║ ➤ .delete or .del
║ ➤ .kick @user
║ ➤ .warnings @user
║ ➤ .warn @user
║ ➤ .antilink
║ ➤ .antibadword
║ ➤ .clear
║ ➤ .tag <message>
║ ➤ .tagall
║ ➤ .chatbot
║ ➤ .resetlink
║ ➤ .welcome <on/off>
║ ➤ .goodbye <on/off>
╚═══════════════════╝

╔═══════════════════╗
🎩 *Owner Commands أوامر المالك*:🎩
║ ➤ .mode
║ ➤ .autostatus
║ ➤ .clearsession
║ ➤ .antidelete
║ ➤ .cleartmp
║ ➤ .setpp <reply to image>
║ ➤ .autoreact
╚═══════════════════╝

╔═══════════════════╗
🖼️ *Image/Sticker Commands أوامر الصورة / الملصق*:
║ ➤ .blur <image>
║ ➤ .simage <reply to sticker>
║ ➤ .sticker <reply to image>
║ ➤ .tgsticker <Link>
║ ➤ .meme
║ ➤ .take <packname> 
║ ➤ .emojimix <emj1>+<emj2>
╚═══════════════════╝  

╔═══════════════════╗
🕹️ *Game Commands أوامر اللعبة*:🕹️
║ ➤ .tictactoe @user
║ ➤ .hangman
║ ➤ .guess <letter>
║ ➤ .trivia
║ ➤ .answer <answer>
║ ➤ .truth
║ ➤ .dare
╚═══════════════════╝

╔═══════════════════╗
🤖 *AI Commands أوامر الذكاء الاصطناعي*:🤖
║ ➤ .gpt <question>
║ ➤ .gemini <question>
║ ➤ .imagine <prompt>
║ ➤ .flux <prompt>
╚═══════════════════╝

╔═══════════════════╗
🤓 *Fun Commands أوامر ممتعة*:🤓
║ ➤ .compliment @user
║ ➤ .insult @user
║ ➤ .flirt 
║ ➤ .shayari
║ ➤ .goodnight
║ ➤ .roseday
║ ➤ .character @user
║ ➤ .wasted @user
║ ➤ .ship @user
║ ➤ .simp @user
║ ➤ .stupid @user [text]
╚═══════════════════╝

╔═══════════════════╗
✒️ *Textmaker صانع النصوص*:✒️
║ ➤ .metallic <text>
║ ➤ .ice <text>
║ ➤ .snow <text>
║ ➤ .impressive <text>
║ ➤ .matrix <text>
║ ➤ .light <text>
║ ➤ .neon <text>
║ ➤ .devil <text>
║ ➤ .purple <text>
║ ➤ .thunder <text>
║ ➤ .leaves <text>
║ ➤ .1917 <text>
║ ➤ .arena <text>
║ ➤ .hacker <text>
║ ➤ .sand <text>
║ ➤ .blackpink <text>
║ ➤ .glitch <text>
║ ➤ .fire <text>
╚═══════════════════╝

╔═══════════════════╗
📥 *Downloader برنامج التنزيل*:📥
║ ➤ .play <song_name>
║ ➤ .song <song_name>
║ ➤ .instagram <link>
║ ➤ .facebook <link>
║ ➤ .tiktok <link>
║ ➤ .video <song name>
║ ➤ .ytmp4 <Link>
╚═══════════════════╝

╔═══════════════════╗
☣️ *Github Commands أوامر جيثب:*☣️
║ ➤ .git
║ ➤ .github
║ ➤ .sc
║ ➤ .script
║ ➤ .repo
╚═══════════════════╝

مرحبا بك في بوت المطور King Saqr يمكنك استخدام البوت هاذي كل اوامر البوت لنا الابداع ولكم الاستمتاع


يمكنك متابعة المطور 

قناة على الواتساب
https://whatsapp.com/channel/0029VbAuIHpCnA81pI0Dza0j

قناة الثانية
https://whatsapp.com/channel/0029VbBFUto2v1IwxHZ4w62Q

موقع المطور👇
https://kingsaqrsami.blogspot.com/2024/03/whatsapp-king-saqr.html?m=1
〰️〰️〰️〰️〰️〰️〰️〰️〰️
قناة التحديثات 👇
https://t.me/+T_8QE67Pn6tkMzNk
〰️〰️〰️〰️〰️〰️〰️〰️〰️
قناتي على اليوتيوب 👇
https://youtube.com/@king_saqr_1?si=e1eR_9Thjb3Z30ON
〰️〰️〰️〰️〰️〰️〰️〰️〰️:`;

    try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
        
        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);
            
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    
                }
            },{ quoted: message });
        } else {
            console.error('Bot image not found at:', imagePath);
            await sock.sendMessage(chatId, { 
                text: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    
                }
            });
        }
    } catch (error) {
        console.error('Error in help command:', error);
        await sock.sendMessage(chatId, { text: helpMessage });
    }
}

module.exports = helpCommand;
